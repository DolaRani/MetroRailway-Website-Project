
 <!-- Footer Section Begin -->
    <footer style ="background-color: #02B6CB;"class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-5 col-sm-6 mt-3">
                    <div class="footer__widget">
                        <h5>Metro</h5>
                        <ul>
                            <li><a href="#"></a></li>
                            <li><p style="color:#fff;">The Dhaka Metro Mass Rapid Transit (MRT) is a new metro rail system being developed by the Dhaka Mass Transit Company (DMTC) in Dhaka, Bangladesh.</p>
                            <li><a style="color:#FFFFFFFF;" href="https://www.railway-technology.com/projects/dhaka-metro-mass-rapid-transit-system/" target=_blank>Read More ...</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 mt-3 ">
                    <div class="footer__widget">
                        <h5>Contact Us</h5>
                        <ul>
                            <li><a href="#" style="color:#FFFFFFFF;">West Razabazar,Dhaka 1205</a></li>
                            <li><a href="#"style="color:#FFFFFFFF;">Phone No : 01700 000 000</a></li>
                            <li><a href="#"style="color:#FFFFFFFF;">Email : metro@gmail.com</a></li>       
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 mt-3">
                    <div class="footer__widget">
                        <h5>Follow Us</h5>
                            <div class="header__right__social">
                            <a style="color:#FFFFFFFF;" href="https://www.facebook.com/" target=_blank><i class="fa fa-facebook"></i></a>
                            <a style="color:#FFFFFFFF;"href="https://twitter.com/"><i class="fa fa-twitter"target=_blank></i></a>
                            <a style="color:#FFFFFFFF;" href="https://www.instagram.com/"><i class="fa fa-instagram"target=_blank></i></a>
                            <a style="color:#FFFFFFFF;" href="https://dribbble.com/"><i class="fa fa-dribbble"target=_blank></i></a>
                        </div>     
                    </div>
                </div>   
            </div>
            <div class="row">
                <div class="col-lg-12 text-center">
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    <div class="footer__copyright__text">
                        <p style="color:#FFFFFFFF;"> &copy; 2020 SoftCare IT. All rights resereved.</strong><a style="color:#FFFFFFFF;"href="http://www.softcareit.com/"  target="_blank"> SoftCare IT </a></p>
                    </div>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                </div>
            </div>    
    </footer>
   
    